package be.kahosl;

import junit.framework.*;

import be.kahosl.error.*;

public class SingletonTest 
    extends TestCase
{
    public SingletonTest( String testName )
    {
        super( testName );
    }

    public static Test suite()
    {
        return new TestSuite( SingletonTest.class );
    }

    public void testLookupObject()
    {
	Assert.assertNotNull(ErrorSingleton.createSingleton());
    }

    public void testSameObjectInConsecutiveLookups() {
       ErrorSingleton objects[] = {ErrorSingleton.createSingleton(), ErrorSingleton.createSingleton(), ErrorSingleton.createSingleton()};
       Assert.assertSame(objects[0], objects[1]);
       Assert.assertSame(objects[1], objects[2]);
    }
}
