package be.kahosl;

import junit.framework.*;

import be.kahosl.recursion.*;

public class FibonacciTest 
    extends TestCase
{
    public FibonacciTest( String testName )
    {
        super( testName );
    }

    public static Test suite()
    {
        return new TestSuite( FibonacciTest.class );
    }

    public void testDoubleArrayRetrieval() {
      int data[][] = {{1, 2}, {3, 4}};
      Assert.assertEquals(data[0][0], 1);
      Assert.assertEquals(data[0][1], 2);
      Assert.assertEquals(data[1][0], 3);
      Assert.assertEquals(data[1][1], 4);
    }

    public void testNegativeN() {
        try {
          Fibonacci fib = new Fibonacci(-1);
          Assert.assertNotNull(fib);
          Assert.assertEquals( fib.getFibNumber(), -1 );
          Assert.fail();
        } catch (Exception exp) {
          // exception is expected
          Assert.assertTrue(true);
        }
    }

    public void testFibonacci()
    {
        int data[][] = {{1, 1}, {2, 1}, {3, 2}, {4, 3}, {5, 5}, {6, 8}};

        try {
          for (int i = 0; i < data.length; i++) {
            Fibonacci fib = new Fibonacci(data[i][0]);
            Assert.assertNotNull(fib);
            Assert.assertEquals( fib.getFibNumber(), data[i][1] );
          }
        } catch (Exception exp) {
          Assert.fail();
        }
    }
}
