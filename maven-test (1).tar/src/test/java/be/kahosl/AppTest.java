package be.kahosl;

import junit.framework.*;

import be.kahosl.*;
import be.kahosl.data.*;

public class AppTest 
    extends TestCase
{
    public AppTest( String testName )
    {
        super( testName );
    }

    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    public void testApp()
    {
        Assert.assertNotNull(new AppManager(Constants.FIBONACCI));
        Assert.assertNotNull(new AppManager(Constants.FACULTY));
        Assert.assertNotNull(new AppManager(Constants.DIGITAL_NUMBERS));
    }
}
