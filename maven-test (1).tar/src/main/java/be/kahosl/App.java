package be.kahosl;

import be.kahosl.error.*;
import be.kahosl.recursion.*;
import be.kahosl.data.*;

/**
 * Start application
 *
 */
public class App 
{
    public static void main( String[] args )
    {
	try {
	  AppManager am = new AppManager(Constants.FIBONACCI);
          am.execute();
        } catch (Exception exp){
          ErrorSingleton.createSingleton().writeError("programme ends unforeseen");
        }
    }
}
