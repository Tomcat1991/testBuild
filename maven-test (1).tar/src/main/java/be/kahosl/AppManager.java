package be.kahosl;

import be.kahosl.data.*;
import be.kahosl.error.*;
import be.kahosl.recursion.*;
import java.io.*;

public class AppManager 
{
  private int recMethod;

  public AppManager(int recMethod) {
    this.recMethod = recMethod;
  }

  public void execute() throws Exception {
    if (recMethod == Constants.FIBONACCI) {
      try {
        System.out.print("Give n: ");

        String input = (new DataInputStream(System.in)).readLine();
	int number = (new Integer(input)).intValue();

        Fibonacci fib = new Fibonacci(number);
        System.out.println("n'th Fibonacci number: " + fib.getFibNumber());
      } catch (Exception exp) {
        System.out.println(exp);
      }
    } else {
      ErrorSingleton.createSingleton().writeError("Recursive method not implemented");
      throw new Exception("Recursive method not implemented");
    }
  }
}
