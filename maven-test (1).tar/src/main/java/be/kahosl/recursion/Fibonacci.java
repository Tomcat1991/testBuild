package be.kahosl.recursion;

import be.kahosl.error.*;

public class Fibonacci 
{
  private long n;

  public Fibonacci(long n) {
    this.n = n;
  }

  public long getFibNumber() throws Exception {
    if (n < 1) {
      ErrorSingleton.createSingleton().writeError("Wrong input number");
      throw new Exception("Fibonacci input");
    }

    return calculate(n);
  }

  private long calculate(long n) {
    if (n < 3) {
      return 1;
    }

    return calculate(n-1) + calculate(n-2);
  }
}
