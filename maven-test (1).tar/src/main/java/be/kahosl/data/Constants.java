package be.kahosl.data;

public class Constants {
  public static final int FIBONACCI = 0;
  public static final int DIGITAL_NUMBERS = 1;
  public static final int FACULTY = 2;
}
