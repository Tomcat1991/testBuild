package be.kahosl;

public class HelloWriter 
{
  private String name;

  public HelloWriter(String name) {
    this.name = name;
  }

  public void write() {
    System.out.println("Hello " + name);
  }
}
