package be.kahosl.error;

public class ErrorSingleton 
{
  private static ErrorSingleton singleton;

  private ErrorSingleton(){}

  public void writeError(String msg) {
    System.err.println("ERROR: " + msg + ".");
  }

  public static ErrorSingleton createSingleton() {
    if (singleton == null) {
      singleton = new ErrorSingleton();
    }

    return singleton;
  }
}
